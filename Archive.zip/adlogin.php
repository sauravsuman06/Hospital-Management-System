<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link rel="stylesheet" type="text/css" href="css/adlogin.css">
</head>
<body>
    <div class="b" align ="center"> LOGGED  IN  AS  ADMIN</div>
    <a href="services.php">
    <button class="button button2">SERVICES</button></a>
    <a href="drdetails.php">
    <button class="button button3">DOCTOR DETAILS</button></a>
    <a href="patdetails.php">
    <button class="button button4">PATIENT DETAILS</button></a>
    <a href="docsignup.php">
    <button class="button button5">NEW DOCTOR</button></a>
    </div>
    </body>
    </head>
    </html>