

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/phar.css">
</head>
<body>

  <body style="background-color:rgb(4,29,49);"></body>
<h1 align="center", style="color:white;"><u>Stocks</u></h1>


  <h2 align="center", style="color:white;"><u>ADD STOCKS</u></h2>
  <div class="column">
   
            
    <div class="form-box">
      
      <div class="input-box">
      <input type="med_name" placeholder="Stock Holder" name="sholder">
      </div>
      <div class="input-box">
      <input type="pptablet" placeholder="Number of Stocks" name="nstock">
      </div>
      <div class="input-box">
      <input type="quantity" placeholder="Stock Value" name ="svalue">
      </div>
      
      <div class="btn">
      <input class="btn" type="submit" name="sadd" value="Add Details"id="add">
      </div>
      
      

      </div>
      
      
      
</body>
</html>

