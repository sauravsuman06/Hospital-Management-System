<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
<link rel="stylesheet" type="text/css" href="css/services.css">
</head>
<body>
    <div class="b" align ="center"> SERVICES</div>
    <a href="accounts.php">
    <button class="button button2">ACCOUNTS</button></a>
    <a href="payroll.php">
    <button class="button button3">PAYROLL</button></a>
    <a href="stocks.php">
    <button class="button button4">STOCKS</button></a>
    <a href="phar.php">
    <button class="button button5">PHARMACY</button></a>
    </div>
    </body>
    </head>
    </html>