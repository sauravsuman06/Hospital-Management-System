<?php
 require 'configdb/db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
<title>APPOINTMENT</title>
<link rel="stylesheet" type="text/css" href="css/appoint.css">
</head>
<body>
<form action="appoint.php" method="post">
    <div class="patprofile"><h1> APPOINTMENT</h1></div>
    <div class="login-box">
            <div id="patid">
</div>
<h2 class="patid">Patient ID</h2>
<input class="id" type="num" name="paid">
<h2 class="patid">Patient Name</h2>
<input class="id" type="text" name="pnam">
<h2 class="sym">Symptoms</h2>
<input class="symptom" type="text" name="patsym">
<h2 class="num">Phone number</h2>
<input class="phn" type="num" name="patphn">
<h2 class= "appoint">CONFIRM APPOINTEMENT</h2>
<h2 class= "apptime">Appointement Time</h2>
<input class="time" type="text" name="time">
<h2 class="Docid">Doctor ID</h2>
<input class="doctor" type="num" name="docid">
<h2 class="bill">BILL</h2>
<input class="bill" type="num" name="appbill">
<button type="submit" name="confirmapp">Confirm Appointement</button>
        </form>
        <?php
    if(isset($_POST['confirmapp']))
    {
        //echo '<script type="text/javascript">alert("sign up clicked")</script>';
        @$paid=$_POST['paid'];
        @$pnam=$_POST['pnam'];
        @$patsym=$_POST['patsym'];
        @$patphn=$_POST['patphn'];
        @$time=$_POST['time'];
        @$docid=$_POST['docid'];
        @$appbill=$_POST['appbill'];

        if($paid=="" || $pnam==""|| $patsym=="" || $patphn=="" || $time=="" || $docid=="" || $appbill=="")
        {
            echo '<script type="text/javascript">alert("Fill all the column")</script>';
        }
        else{
            $query= "insert into appointment values($paid,'$pnam','$patsym',$patphn,$time,$docid,$appbill)";
		 $query_run=mysqli_query($con,$query);
		 if($query_run)
		 {
			echo '<script type="text/javascript">alert("Appointement Confirmed")</script>';
		 }
		 else{
			echo '<script type="text/javascript">alert("Values not inserted ")</script>';
		 }
        }
    }
?>
        </div>
        </body>
</html>
