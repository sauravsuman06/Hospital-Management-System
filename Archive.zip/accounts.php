<?php
 require 'configdb/db.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/phar.css">
</head>
<body>
<form action="accounts.php" method="post">
  <body style="background-color:rgb(4,29,49);"></body>
<h1 align="center", style="color:white;"><u>ACCOUNTS</u></h1>


  <h2 align="center", style="color:white;"><u> ADD ACCOUNT DETAILS</u></h2>
  <div class="column">
   
            
    <div class="form-box">
      
      <div class="input-box">
      <input type="med_name" placeholder="Account No." name="acno">
      </div>
      <div class="input-box">
      <input type="pptablet" placeholder="Description" name="desc">
      </div>
      <div class="input-box">
      <input type="quantity" placeholder="Transaction ID" name ="tid">
      </div>
      <div class="input-box">
      <input type="status" placeholder="Amount" name="amt">
      </div>
      <div class="btn">
      <input class="btn" type="submit" name="aadd" value="Add Details"id="add">
      </div>
      <div class="btn">
      <a href="seeaccounts.php">
        <input class="btn" type="button" name="seeacc" value="See Accounts"id="cstock"></a>
      </div>
</form>
<?php
    if(isset($_POST['aadd']))
    {
        //echo '<script type="text/javascript">alert("sign up clicked")</script>';
        @$acno=$_POST['acno'];
        @$desc=$_POST['desc'];
        @$tid=$_POST['tid'];
        @$amt=$_POST['amt'];
        
        if($acno=="" || $desc=="" || $tid=="" || $amt=="")
        {
            echo '<script type="text/javascript">alert("Fill all the column")</script>';
        }
        else{
            $query= "insert into account values($acno,'$desc',$tid,$amt)";
		 $query_run=mysqli_query($con,$query);
		 if($query_run)
		 {
			echo '<script type="text/javascript">alert("Details Added")</script>';
		 }
		 else{
			echo '<script type="text/javascript">alert("Values not inserted ")</script>';
		 }
        }
    }
?>
</div>
</body>
</html> 