<!DOCTYPE html>
<html>
<head>
<title>HOSPITAL MANAGEMENT</title>
<link rel="stylesheet" type="text/css" href="css/front.css">
</head>
<body>
<header>
<div class="main">
</div>
<div class="title">
    <h1>HOSPITAL MANAGEMENT</h1>
    <h2>The skill to heal, the spirit to care</h2>
</div>
<div class="button">
    <a href="admin.php" class="btn">ADMIN LOGIN</a>
    <a href="receptionistlogin.php" class="btn">RECEPTIONIST LOGIN</a>
    <a href="docprofile.php" class="btn">DOCTOR LOGIN</a>
    <a href="patprofile.php" class="btn">PATIENT LOGIN</a>
    <a href="staffsch.php" class="btn">CHECK STAFF SCHEDULE</a>
</div>
</header>
</body>
</html>