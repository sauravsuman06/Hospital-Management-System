<?php
 require 'configdb/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
<title>DOCTOR LOGIN</title>
<link rel="stylesheet" type="text/css" href="css/doclogin.css">
</head>
<body>
<form action="doclogin.php" method="post">
    <div class="login-box">
<h1>Login Here</h1>
<div class="input-box">
<input type="email" placeholder="Email Id" name="docemail">
</div>
<div class="input-box">
<input type="password" placeholder="Password" name="password">
</div>

<input class="btn" type="submit" name="login" value="Sign in">
</form>
<?php
    if(isset($_POST['login']))
    {
      //echo '<script type="text/javascript">alert("Php Working")</script>';
      $docemail=$_POST['docemail'];
      $password=$_POST['password'];
      $query= "select * from docsignup WHERE docemail='$docemail'AND password='$password'";
      $query_run = mysqli_query($con,$query);
      if(mysqli_num_rows($query_run)>0)
      {
          $_SESSION['docemail']= $docemail;
          header('location:docprofile.php');
      }
      else{
          echo '<script type="text/javascript">alert("Invalid Credentials")</script>';
      }
    }

?>
</div>
</body>
</html>