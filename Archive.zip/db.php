<?php
$con = mysqli_connect("localhost","root","")OR die("cannot connect");
mysqli_select_db($con,'hospitalmanagement');
?>