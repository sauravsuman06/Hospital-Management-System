<?php
 require 'configdb/db.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
<title>DOCTOR'S PROFILE SIGN UP</title>
<link rel="stylesheet" type="text/css" href="css/docsignup.css">
</head>
<body>
    <div class="login-box">
    <form action="docsignup.php" method="post">
<h1>Doctor Signup</h1>
<div class="input-box">
<input type="email" placeholder="Email Id" name="docemail">
</div>
<div class="input-box">
<input type="password" placeholder="Password" name="password">
</div>
<div class="input-box">
<input type="id" placeholder="Registration ID" name="regisid">
</div>
<div class="input-box">
<input type="name" placeholder="Name" name="drname">
</div>
<div class="input-box">
<input type="age" placeholder="Specialization" name="special">
</div>
<div class="input-box">
<input type="qu" placeholder="Qualification" name="qual">
</div>
<div class="input-box">
<input type="add" placeholder="Year Of Experience" name="yoe">
</div>
<input class="btn" type="submit" name="submitbutton" value="Submit" id="SubmitBtn">
</form>
<?php
    if(isset($_POST['submitbutton']))
    {
        //echo '<script type="text/javascript">alert("sign up clicked")</script>';
        @$docemail=$_POST['docemail'];
        @$password=$_POST['password'];
        @$regisid=$_POST['regisid'];
        @$drname=$_POST['drname'];
        @$special=$_POST['special'];
        @$qual=$_POST['qual'];
        @$yoe=$_POST['yoe'];

        if($docemail=="" || $password=="" || $regisid=="" || $drname=="" || $special=="" || $qual=="" || $yoe=="")
        {
            echo '<script type="text/javascript">alert("Fill all the column")</script>';
        }
        else{
            $query= "insert into docsignup values('$docemail','$password',$regisid,'$drname','$special','$qual',$yoe)";
		 $query_run=mysqli_query($con,$query);
		 if($query_run)
		 {
			echo '<script type="text/javascript">alert("Inserted successfully")</script>';
		 }
		 else{
			echo '<script type="text/javascript">alert("Values not inserted ")</script>';
		 }
        }
    }
?>
</div>
</body>
</html> 